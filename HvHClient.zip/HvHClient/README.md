# HvHClient

Minecraft 1.20.1 Fabric client mod. Menu key: **N**.

## Modules
- **AutoInventoryTotem**: Enabled, Auto Open, Auto Close, Hover, Health, Totem Slot, Delay, Prehit
- **SelfDestruct**: deletes the config and mod jar after confirmation

## AutoInventoryTotem
- Health is based on `getHealth()` only (absorption hearts are not counted).
- Auto Open: opens the inventory and equips a totem when health is low.
- Auto Close: closes the inventory after equipping.
- Even with Auto Open/Close off, an open inventory equips a totem when health is low.
- Hover: when enabled, an open inventory also refills the Totem Slot automatically.
- Delay: ticks between actions (20 ticks = 1 second).
- Prehit: holding a firework rocket and a player within 4 blocks, switches to the best hotbar sword. After switching, if the crosshair is on a player within 3 blocks, hits once (ignores attack cooldown).

## Build
Requires Java 17. Add the Gradle wrapper first (`gradle wrapper --gradle-version 8.5`), then:

    ./gradlew build

The jar is in `build/libs/`.
