package com.example.hvh;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class TotemScreen extends Screen {
    private final Screen parent;

    public TotemScreen(Screen parent) {
        super(Text.literal("AutoInventoryTotem"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        Config c = Config.get();
        int x = width / 2 - 100, y = height / 2 - 80;
        toggle(x, y, "Enabled", () -> c.totemEnabled, v -> c.totemEnabled = v);
        toggle(x, y + 24, "Auto Open", () -> c.autoOpen, v -> c.autoOpen = v);
        toggle(x, y + 48, "Auto Close", () -> c.autoClose, v -> c.autoClose = v);
        toggle(x, y + 72, "Hover", () -> c.hover, v -> c.hover = v);
        addDrawableChild(new SliderWidget(x, y + 96, 200, 20, Text.empty(), (c.health - 1) / 19.0) {
            { updateMessage(); }
            @Override protected void updateMessage() {
                setMessage(Text.literal("Health: " + Config.get().health));
            }
            @Override protected void applyValue() {
                Config.get().health = Math.round((1 + value * 19) * 2) / 2f;
            }
        });
        addDrawableChild(ButtonWidget.builder(Text.literal("Totem Slot: " + c.totemSlot), b -> {
            c.totemSlot = c.totemSlot % 9 + 1;
            b.setMessage(Text.literal("Totem Slot: " + c.totemSlot));
        }).dimensions(x, y + 120, 200, 20).build());
        addDrawableChild(new SliderWidget(x, y + 144, 200, 20, Text.empty(), Config.get().delay / 20.0) {
            { updateMessage(); }
            @Override protected void updateMessage() {
                setMessage(Text.literal("Delay: " + Config.get().delay + " tick"));
            }
            @Override protected void applyValue() {
                Config.get().delay = (int) Math.round(value * 20);
            }
        });
        toggle(x, y + 168, "Prehit", () -> c.prehit, v -> c.prehit = v);
    }

    private void toggle(int x, int y, String name, BooleanSupplier get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(x, y, 200, 20).build());
    }

    private Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public void close() { client.setScreen(parent); }

    @Override
    public void removed() { Config.save(); }
}
