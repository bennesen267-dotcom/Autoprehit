package com.example.hvh;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public class AutoInventoryTotem {
    private static boolean equippedThisOpen = false;
    private static int cooldown = 0;

    public static void tick(MinecraftClient mc) {
        Config cfg = Config.get();
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || !cfg.totemEnabled) return;

        prehit(mc, p, cfg);

        if (!(mc.currentScreen instanceof InventoryScreen)) equippedThisOpen = false;

        if (cooldown > 0) { cooldown--; return; }

        boolean low = p.getHealth() <= cfg.health; // sarı kalpler dahil değil
        boolean offhandTotem = p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);

        // Auto open
        if (cfg.autoOpen && low && !offhandTotem && mc.currentScreen == null && findTotem(p, -1, -1) != -1) {
            mc.setScreen(new InventoryScreen(p));
            cooldown = cfg.delay;
            return;
        }

        if (!(mc.currentScreen instanceof InventoryScreen)) return;
        int syncId = p.playerScreenHandler.syncId;
        int hotbarId = 36 + (cfg.totemSlot - 1);

        // 1) Offhand (health'e göre)
        if (low && !offhandTotem) {
            int src = findTotem(p, cfg.totemSlot, -1);
            if (src != -1) {
                mc.interactionManager.clickSlot(syncId, src, 40, SlotActionType.SWAP, p);
                equippedThisOpen = true;
                cooldown = cfg.delay;
                return;
            }
        }

        // 2) Hover: Totem Slot boşsa envanterdeki başka bir totemi oraya at
        if (cfg.hover) {
            boolean slotHasTotem = p.playerScreenHandler.slots.get(hotbarId)
                    .getStack().isOf(Items.TOTEM_OF_UNDYING);
            if (!slotHasTotem) {
                int src = findTotem(p, -1, hotbarId);
                if (src != -1) {
                    mc.interactionManager.clickSlot(syncId, src, cfg.totemSlot - 1,
                            SlotActionType.SWAP, p);
                    cooldown = cfg.delay;
                    return;
                }
            }
        }

        // 3) Auto close
        if (cfg.autoClose && equippedThisOpen && p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            p.closeHandledScreen();
            equippedThisOpen = false;
            cooldown = cfg.delay;
        }
    }

    private static final double PREHIT_RANGE = 4.0;
    private static final double PREHIT_REACH = 3.0;
    private static int prehitSlot = -1; // -1: kılıca geçilmedi

    /**
     * Elde havai fişek varken 4 blok içinde oyuncu varsa sadece kılıca geçer.
     * Kılıca geçtikten sonra nişan oyuncunun üzerindeyse ve mesafe 3 blokluk erişimin içindeyse
     * bir kez vurur (cooldown'a bakmaz).
     */
    private static void prehit(MinecraftClient mc, ClientPlayerEntity p, Config cfg) {
        if (!cfg.prehit || mc.currentScreen != null || mc.world == null
                || mc.getNetworkHandler() == null || !p.isAlive()) {
            prehitSlot = -1;
            return;
        }

        if (prehitSlot != -1) {
            if (p.getInventory().selectedSlot != prehitSlot || nearestPlayer(mc, p, PREHIT_RANGE) == null) {
                prehitSlot = -1;
                return;
            }
            if (mc.crosshairTarget instanceof EntityHitResult hit
                    && hit.getEntity() instanceof PlayerEntity target
                    && target != p && target.isAlive() && !target.isSpectator()
                    && p.getEyePos().distanceTo(hit.getPos()) <= PREHIT_REACH) {
                mc.interactionManager.attackEntity(p, target);
                p.swingHand(Hand.MAIN_HAND);
                prehitSlot = -1;
            }
            return;
        }

        if (!p.getMainHandStack().isOf(Items.FIREWORK_ROCKET)) return;
        if (nearestPlayer(mc, p, PREHIT_RANGE) == null) return;

        int sword = findSword(p);
        if (sword == -1) return;

        p.getInventory().selectedSlot = sword;
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(sword));
        prehitSlot = sword;
    }

    private static PlayerEntity nearestPlayer(MinecraftClient mc, ClientPlayerEntity p, double range) {
        PlayerEntity nearest = null;
        double best = range * range;
        for (PlayerEntity other : mc.world.getPlayers()) {
            if (other == p || !other.isAlive() || other.isSpectator()) continue;
            double d = p.squaredDistanceTo(other);
            if (d <= best) { best = d; nearest = other; }
        }
        return nearest;
    }

    /** Hotbar'daki en yüksek hasarlı kılıcın slotu (0-8), yoksa -1. */
    private static int findSword(ClientPlayerEntity p) {
        int bestSlot = -1;
        float bestDamage = -1f;
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getStack(i).getItem() instanceof SwordItem sw
                    && sw.getAttackDamage() > bestDamage) {
                bestDamage = sw.getAttackDamage();
                bestSlot = i;
            }
        }
        return bestSlot;
    }

    /** Modül envanterde işlem yapacakken true döner (bu sırada tık/tuş engellenir). */
    public static boolean busy(MinecraftClient mc) {
        Config cfg = Config.get();
        ClientPlayerEntity p = mc.player;
        if (SelfDestruct.done || p == null || !cfg.totemEnabled) return false;
        if (!(mc.currentScreen instanceof InventoryScreen)) return false;

        boolean low = p.getHealth() <= cfg.health;
        boolean offhandTotem = p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
        int hotbarId = 36 + (cfg.totemSlot - 1);

        if (low && !offhandTotem && findTotem(p, cfg.totemSlot, -1) != -1) return true;
        if (cfg.hover) {
            boolean slotHasTotem = p.playerScreenHandler.slots.get(hotbarId)
                    .getStack().isOf(Items.TOTEM_OF_UNDYING);
            if (!slotHasTotem && findTotem(p, -1, hotbarId) != -1) return true;
        }
        return cfg.autoClose && equippedThisOpen && offhandTotem;
    }

    /** preferredHotbar: 1-9 öncelikli slot (-1 yok), exclude: atlanacak slot id (-1 yok) */
    private static int findTotem(ClientPlayerEntity p, int preferredHotbar, int exclude) {
        var slots = p.playerScreenHandler.slots;
        if (preferredHotbar >= 1 && preferredHotbar <= 9) {
            int id = 36 + (preferredHotbar - 1);
            if (id != exclude && slots.get(id).getStack().isOf(Items.TOTEM_OF_UNDYING)) return id;
        }
        for (int i = 9; i <= 44; i++) {
            if (i != exclude && slots.get(i).getStack().isOf(Items.TOTEM_OF_UNDYING)) return i;
        }
        return -1;
    }
}
